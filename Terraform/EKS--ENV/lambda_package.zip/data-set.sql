
INSERT INTO [Hotel] (Chief, Name, Location, Rating, Facilities) VALUES
('Ahmed', 'Nile Plaza Hotel', 'Cairo, Egypt', 4, 'Swimming Pool, Gym, Restaurant, WiFi, Parking'),
('Mohammed', 'Pyramids View Resort', 'Giza, Egypt', 4, 'Swimming Pool, Gym, Restaurant, WiFi, Spa'),
('Fatima', 'Red Sea Oasis Hotel', 'Hurghada, Egypt', 5, 'Swimming Pool, Gym, Restaurant, WiFi, Conference Room'),
('Ali', 'Luxor Palace Hotel', 'Luxor, Egypt', 4, 'Swimming Pool, Gym, Restaurant, WiFi, Rooftop Lounge'),
('Aisha', 'Alexandria Beach Resort', 'Alexandria, Egypt', 4, 'Swimming Pool, Gym, Restaurant, WiFi, Beach Access');
